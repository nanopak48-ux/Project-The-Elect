using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonoGame.Extended.Animations;
using MonoGame.Extended.Graphics;
using Project_The_Elect;
using Project_The_Elect.source_code;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_The_Elect
{
    public class StateDialogue : IGameState
    {
        private SpriteBatch _spriteBatch;
        private DialogueManager _dialogueManager;
        private DialogueSprite _dialoguesprite;

        private int _currentDialogueIndex = 0;
        private int _previousDialogueIndex = 0;

        private bool _isNextDialogue = true;
        private bool _isPlayingBGM;

        private ChapterData chapter;
        private DialogueData current;
        private GameTextManager _fontManager;
        private GameAudioManager _audioManager;
        private GameStateManager _gameStateManager;

        private GameFlowManager _gameFlow;

        private GameButtonGuide _gameButtonGuide;
        private int screenWidth;
        private int screenHeight;

        private KeyboardState _previousKeyboardState;
        private MouseState _previousMouseState;

        private bool _isPlayedVoiceline = false;
        private ContentManager contentManager;
        private bool _returnToPreviousState;
        private bool _startQuestAfterReturn;
        private Action _afterReturn;

        public StateDialogue
            (
            int _chapterIndex,
            ContentManager _contentManager,
            GameStateManager gameStateManager,
            SpriteBatch spriteBatch,
            GameAudioManager audioManager,
            GameFlowManager gameflow,
            int screenWidth,
            int screenHeight,
            bool returnToPreviousState = false,
            bool startQuestAfterReturn = false,
            Action afterReturn = null
            )
        {
            _dialogueManager = new DialogueManager(_contentManager);
            _dialoguesprite = new DialogueSprite(_contentManager, spriteBatch, audioManager, screenWidth, screenHeight);
            _gameButtonGuide = new GameButtonGuide(gameStateManager, _contentManager, spriteBatch);
            this.screenWidth = screenWidth;
            this.screenHeight = screenHeight;
            _gameStateManager = gameStateManager;
            _fontManager = new GameTextManager(_contentManager, spriteBatch);
            _gameFlow = gameflow;
            _returnToPreviousState = returnToPreviousState;
            _startQuestAfterReturn = startQuestAfterReturn;
            _afterReturn = afterReturn;
            _spriteBatch = spriteBatch;
            _audioManager = audioManager;
            _gameStateManager = gameStateManager;


            if (_chapterIndex < 10) chapter = _dialogueManager.LoadChapter("Content/data/dataDialogue/chapter0" + _chapterIndex + ".json");
            else chapter = _dialogueManager.LoadChapter("Content/data/dataDialogue/chapter" + _chapterIndex + ".json");





            if (chapter?.dialogues != null && chapter.dialogues.Count > 0)
            {
                _dialogueManager._dialogues = chapter.dialogues;
            }
            current = _dialogueManager.GetDialogue(_currentDialogueIndex);

            _audioManager.LoadDialogueVoicelines(chapter, _contentManager);
            _isPlayingBGM = false;
            contentManager = _contentManager;
        }

        public void Update(GameTime gameTime)
        {
            if (_returnToPreviousState)
                _gameStateManager.UpdatePreviousState(gameTime);

            _gameButtonGuide.Update(gameTime, _gameStateManager);

            current = _dialogueManager.GetDialogue(_currentDialogueIndex);
            _fontManager.Update(gameTime, current, _isNextDialogue);
            if (_isNextDialogue) { _isNextDialogue = false; }
        }

        public void Draw(GameTime gameTime)
        {
            if (_returnToPreviousState)
                _gameStateManager.DrawPreviousState(gameTime);

            _spriteBatch.Begin();
            //DRAW PROFILE & BG
            _dialoguesprite.Draw(gameTime, current);

            //DRAW TEXT
            _fontManager.DrawDialogue(gameTime, current);

            //DRAW BUTTONS
            _gameButtonGuide.DrawBtnGuide(gameTime, _gameStateManager);

            _spriteBatch.End();
        }

        public void InputHandler(GameTime gametime)
        {
            KeyboardState currentKeyboardState = Keyboard.GetState();
            MouseState currentMouseState = Mouse.GetState();

            bool spacePressed = currentKeyboardState.IsKeyDown(Keys.Space) && _previousKeyboardState.IsKeyUp(Keys.Space);
            bool keyEscapePressed = currentKeyboardState.IsKeyDown(Keys.Escape) && _previousKeyboardState.IsKeyUp(Keys.Escape);
            bool mouseClicked = currentMouseState.LeftButton == ButtonState.Pressed && _previousMouseState.LeftButton == ButtonState.Released;
            bool keyDownPresed = currentKeyboardState.IsKeyDown(Keys.Down) && _previousKeyboardState.IsKeyUp(Keys.Down);
            bool keyUpPressed = currentKeyboardState.IsKeyDown(Keys.Up) && _previousKeyboardState.IsKeyUp(Keys.Up);

            if (spacePressed || mouseClicked || currentKeyboardState.IsKeyDown(Keys.Enter))
            {
                if (_currentDialogueIndex < _dialogueManager._dialogues.Count - 1)
                {
                    _currentDialogueIndex++;
                    _isNextDialogue = true;
                    _isPlayedVoiceline = false;
                    _audioManager.PlaySFX("skipdia");
                }
                else
                {
                    if (_returnToPreviousState)
                    {
                        if (_startQuestAfterReturn)
                            _gameFlow.StartQuestAfterBriefing();
                        _gameStateManager.StateReturn();
                        _afterReturn?.Invoke();
                    }
                    else
                        _gameFlow.DialogueEnd();
                }
            }

            if (keyEscapePressed)
            {
                _gameStateManager.StatePush(new StateMenu(contentManager, _gameStateManager, _spriteBatch, _audioManager));
            }

            if (keyUpPressed)
            {
                _audioManager.VolumeControl(10f, 0);
            }

            if (keyDownPresed)
            {
                _audioManager.VolumeControl(-10f, 0);
            }


            _previousKeyboardState = currentKeyboardState;
            _previousMouseState = currentMouseState;

        }
        public void AudioHandler(GameTime gameTime)
        {
            if (!_isPlayingBGM)
            {
                _audioManager.PlayBGM(2);
                _isPlayingBGM = true;
            }

            if (_isPlayedVoiceline == false)
            {
                _audioManager.PlayVoicelines(_currentDialogueIndex);
                _isPlayedVoiceline = true;
            }
        }

    }
}



