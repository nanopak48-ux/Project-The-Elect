using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using MonoGame.Extended.BitmapFonts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace Project_The_Elect.source_code
{
    public class GameTextManager
    {
        public SpriteFont MainFont { get; private set; }
        //public BitmapFont DialogueFont { get; private set; }
        //public BitmapFont ProfileFont { get; private set; }

        private SpriteBatch _spriteBatch;

        private Vector2 _profilePos;

        private Vector2 _dialoguePos;
        private float _dialogueScale = 1.2f;
        private float _profileScale = 2.0f;

        private List<char> _dialogueline = new List<char>();
        private int _dialogueCharIndex = 0;

        private List<char> _dialoguedisplay = new List<char>();

        private bool _isPlayingTextAnim = false;

        private DialogueData _dialogueData;

        private BitmapFont DialogueFont;
        private BitmapFont ProfileFont;

        public GameTextManager(ContentManager content, SpriteBatch spriteBatch)
        {
            _spriteBatch = spriteBatch;
            //ProfileFont = content.Load<SpriteFont>("font/zh-cn");
            //DialogueFont = content.Load<BitmapFont>("font/fontGenshin");

            DialogueFont = content.Load<BitmapFont>("font/fontGenshin");
            ProfileFont = DialogueFont;

            _dialoguePos = new Vector2(270, 820);
        }

        public void Update(GameTime gameTime, DialogueData current, bool isNextDialogue)
        {
            if (isNextDialogue)
            {
                _dialoguePos = new Vector2(230, 820);
                _dialogueline.Clear();
                _dialoguedisplay.Clear();
                _dialogueCharIndex = 0;
                foreach (char c in current.text)
                {
                    _dialogueline.Add(c);
                }
                _isPlayingTextAnim = true;
                string profileName = current.character.ToUpper();
                float profileNameWidth = ProfileFont.MeasureString(profileName).Width * _profileScale;
                const float profileImageX = 150f;
                const float profileImageWidth = 278f;
                _profilePos = new Vector2(
                    profileImageX + (profileImageWidth - profileNameWidth) / 2f,
                    730f);
            }

            if (_isPlayingTextAnim)
            {
                if (_dialogueCharIndex < current.text.Length)
                {
                    _dialoguedisplay.Add(_dialogueline[0]);
                    _dialogueline.RemoveAt(0);
                    _dialogueCharIndex++;
                }
                else
                {
                    _isPlayingTextAnim = false;
                }
            }
        }

        public void DrawDialogue(GameTime gametime, DialogueData current)
        {
            //DRAW TEXT 
            _spriteBatch.DrawString(DialogueFont, new string(_dialoguedisplay.ToArray()), _dialoguePos, Color.White, 0f, Vector2.Zero, _dialogueScale, SpriteEffects.None, 0f);
            _spriteBatch.DrawString(ProfileFont, current.character.ToUpper(), _profilePos, Color.White, 0f, Vector2.Zero, _profileScale, SpriteEffects.None, 0f);

        }

        public void Draw(List<string> TextList, int firstTextOffsetX = 0)
        {
            for (int i = 0; i < TextList.Count; i++)
            {
                int firstItemOffset = i == 0 ? firstTextOffsetX : 0;
                _spriteBatch.DrawString(
                    DialogueFont,
                    TextList[i],
                    new Vector2(1818 - (i * 108) - firstItemOffset, 1038),
                    Color.White);
            }
        }
    }
}
